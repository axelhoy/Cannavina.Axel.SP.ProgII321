package sp.prograii321;

public enum Clase {
    GUERRERO,
    MAGO,
    ARQUERO
}

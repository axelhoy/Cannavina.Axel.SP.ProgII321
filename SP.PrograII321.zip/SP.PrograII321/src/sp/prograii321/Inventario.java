package sp.prograii321;

import sp.prograii321.Personaje;
import java.io.*;
import java.util.*;
import java.util.function.*;

    public class Inventario<T> implements Serializable {
    private List<T> elementos = new ArrayList<>();

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public void eliminar(T elemento) {
        elementos.remove(elemento);
    }

    public void paraCadaElemento(Consumer<T> accion) {
        elementos.forEach(accion);
    }

    public void ordenar() {
        elementos.sort(null);
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    public void transformar(Function<T, T> transformacion) {
        ListIterator<T> iterador = elementos.listIterator();
        while (iterador.hasNext()) {
            iterador.set(transformacion.apply(iterador.next()));
        }
    }

    public void guardarEnArchivo(String ruta) throws IOException { // se lanza cuando hay un problema escribiendo el archivo
        try (ObjectOutputStream OOStream = new ObjectOutputStream(new FileOutputStream(ruta))) {
            OOStream.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException { 
    // lanza excepcion cuando hay un problema con el archivo, o si en ejecucion no se encuentra la clase 
        try (ObjectInputStream OIStream = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) OIStream.readObject();
        }
    }

    public void guardarEnCSV(String ruta) throws IOException {
        // lanza excepcion cuando no se puede crear el archivo o en su escritura
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                if (elemento instanceof Personaje) {
                    bw.write(((Personaje) elemento).toCSV());
                    bw.newLine();
                }
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> funcion) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            if (!elementos.isEmpty()) {
            for (int i = elementos.size() - 1; i >= 0; i--) {
                eliminar(elementos.get(i));
            }
        } // Elimino lo que haya en la lista cargada y añado los que estan en el CSV
            // Esto es necesario ya que en el main nunca se refresca la lista cuando se carga el csv o se crea una nueva, queda la del archivo cargada
            String linea;
        while ((linea = br.readLine()) != null) {
            agregar(funcion.apply(linea)); 
        }
    }
}

}

package sp.prograii321;

import java.io.Serializable;

public class Personaje implements Comparable<Personaje>, Serializable {
    private int id;
    private String nombre;
    private Clase clase;
    private int nivel;

    public Personaje(int id, String nombre, Clase clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public Clase getClase() {
        return clase;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getNivel() {
        return nivel;
    }
    
    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Clase: " + clase + ", Nivel: " + nivel;
    }
    
    @Override
    public int compareTo(Personaje otro) { // para que su orden natural sea el nombre
        return this.nombre.compareTo(otro.nombre);
    }

    public static Personaje fromCSV(String linea) {
        
        String[] partes = linea.split(",");
        int id = Integer.parseInt(partes[0].trim());
        String nombre = partes[1].trim();
        Clase clase = Clase.valueOf(partes[2].trim().toUpperCase());
        int nivel = Integer.parseInt(partes[3].trim());
        return new Personaje(id, nombre, clase, nivel);
    }

    public String toCSV() {
        return id + "," + nombre + "," + clase + "," + nivel;
    }
}
